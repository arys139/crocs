all new issues should include the following:
- description of the issue and steps to reproduce
- jsfiddle that reproduces your issue in its simplest form possible [required]

- browser name/version
- OS name
- jQuery version if not latest
- floatThead version if not latest

no jsfiddle == your issue will be closed
